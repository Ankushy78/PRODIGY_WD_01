function myFunction() {
  var x = document.getElementById("landingpage");
  if (x.className === "landing") {
    x.className += " responsive";
  } else {
    x.className = "landing";
  }
}